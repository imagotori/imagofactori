---
layout: product
published: true
title:  CONCORD
lang: en
product_group: concord
product_type: Display
dimensions: 2 different size
production_leadtime: 35 days per batch (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   Concord-display.jpg
image2:  Concord-display-B.jpg
---
Product specifications: grooved MDF black mat lacquered, extandable backboard and base, glossy varnish silkscreen, removable wings grooved in black mat lacquered MDF and alumi

