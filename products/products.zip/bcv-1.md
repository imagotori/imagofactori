---
layout: product
published: true
title:  BCV
lang: en
product_group: bcv
product_type: Flip flop
dimensions: 8 different size
production_leadtime: 32 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:  BCV-tong.jpg
---
Product specifications: EVA foam laser cutt, silkscreened logo and communication design, polybag and transportation carton

