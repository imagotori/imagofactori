---
layout: product
published: true
title:  CONCORD
lang: en
product_group: concord
product_type: Hong Kong shop in shop
dimensions: multiple item, approx. 14m2
production_leadtime: 30 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - installation
image1:   Concord-HK-sis.jpg
---
Product specifications: Furnitures_ MDF black mat lacquered, removable aluminium corners, exclusive imago factori LED lighting (LED bar and LED shower lighting), storage, crystal cle

