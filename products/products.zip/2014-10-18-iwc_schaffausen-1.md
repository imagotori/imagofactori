---
layout: product
published: true
title:  IWC SCHAFFAUSEN
lang: en
product_group: iwc_schaffausen
product_type: Travel game set
dimensions: W 21cm X D 16.5cm x H 5cm
production_leadtime: 28 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: technical_development sample_production
image1:   IWC-card-set-.jpg
image2:  IWC-card-set-open.jpg
---
Product specifications:  Oxford fabric, italian soft leather, stitching cord in beige 2x card set, 7x dices, 1x pen, 1x paper , delivered in a velevet brown pouch with logo embossment						
