---
layout: product
published: true
title:  RAYMOND WEIL
lang: en
product_group: raymond_weil
product_type: Baselworld gift kit
dimensions: W 18cm X D 8.5cm x H 5cm
production_leadtime: 22 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design technical_development sample mass_production QC logistic shipping
image1:   RW-gift-kit.jpg
---
Product specifications:  high standard quality earphone customized in client color code, logo laser engraved on the earplug, 8GB samsung chip aluminium USB key (credit card size) laser engravement of a decorative pattern, carton box in brown and aluminium  color , glossy silkscreen of the decorative pattern, delivered in transportation carton						
