---
layout: product
published: true
title:  ON DEMAND - CONFIDENTIALITY POLICY 
lang: en
product_group: on_demand_-_confidentiality_policy
product_type: Luxurious travel bag
dimensions: W 60cm X D 30cm x H 32cm
production_leadtime: 35 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   sac-voyage.jpg
---
Product specifications: italian split cow leather brown color, YKK zipper, inside upholstery in silk oxford fabric, 2 compartments inside, 3 pockets, delivered in a brown branded bag and in

