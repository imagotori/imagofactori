---
layout: product
published: true
title:  RAYMOND WEIL
lang: en
product_group: raymond_weil
product_type: Iphone case
dimensions: W 6cm X D 1cm x H 12.5cm
production_leadtime: 21 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   RW-iphone-case.jpg
---
Product specifications: injected PP rubber finishing Iphone case customized with client color, IMD technology have been used to avoid scratches, glossy varnish decorative pattern, silver

