---
layout: product
published: true
title:  SHANGHAI TANG
lang: en
product_group: shanghai_tang
product_type: Backgammon
dimensions: W 26.5cm X D 22cm x H 8cm
production_leadtime: 34 days
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   Shanghai-tang-backgammon-A.jpg
image2:  Shanghai-tang-backgammon-B.jpg
---
Product specifications: base in MDF, glossy black lacquer, oak wood veneer , star and backgammon gmae in marquetry tainted in green and black, dices, wood pawns silkscreened, chro

