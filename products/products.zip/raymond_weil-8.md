---
layout: product
published: true
title:  RAYMOND WEIL
lang: en
product_group: raymond_weil
product_type: Silk scarf & Printed leather kit
dimensions: W 18.5cm X D 10.5cm x H 3.5cm
production_leadtime: 28 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   RW-scarf.jpg
---
Product specifications: 100% wild silk scarf, printed on one side , printed leather kit including an inside upholstery as well a YKK zipper, delivered with a brown carton box silver silkscree

