---
layout: product
published: true
title:  RAYMOND WEIL
lang: en
product_group: raymond_weil
product_type: Leather Iphone and Samsung case
dimensions: W 8.5cm X D 15cm x H 0.8cm
production_leadtime: 30 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   RW-leather-case.jpg
---
Product specifications: rancho leather, pattern and logo embossment, delivered in a brown velvet pouch with hot stamping logo and transportation carton

