---
layout: product
published: true
title:  ON DEMAND - CONFIDENTIALITY POLICY
lang: en
product_group: on_demand_-_confidentiality_policy
product_type: Ski goggle
dimensions: W 19cm X D 3.5cm x H 9cm
production_leadtime: 32 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: technical_development sample mass_production QC logistic shipping
image1:   Lunette-ski.jpg
---
Product specifications:  injected silicone, UV and UB proof grade 4, triple layer protection, P80 anti-fog, flow technology for ventilation, delivered in a branded carton and in carton transportation box						
