---
layout: product
published: true
title:  HARRY WINSTON
lang: en
product_group: harry_winston
product_type: Jewellery box
dimensions: W 25cm X D 20cm x H 32 cm
production_leadtime: 38 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design technical_development sample mass_production QC logistic shipping
image1:   HW-JBox1.jpg
image2:  HW-JBox2.jpg
---
Product specifications:  MDF black piano lacquer finishing, HW silver silkscreen, opening button in stainless steel chrome finishing , inside upholstery in kamosho- black, inside logo in silver hot stamping, removable neckless pouch, delivered with a black mat wibalin paper carton box silver silkscreen logo on the top						
