---
layout: product
published: true
title:  HARRY WINSTON
lang: en
product_group: harry_winston
product_type: Watch box
dimensions: W 30cm X D 25cm x H 15cm
production_leadtime: 40 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   HW-opus-1.jpg
image2:  HW-opus-2.jpg
---
Product specifications: MDF black piano lacquer finishing, 8 mat varnish silks- creen, hardware black anonized, inside upholstery in bukana black, removable tray, 8 embossment, inside

