---
layout: product
published: true
title:  MELAZIC
lang: en
product_group: melazic
product_type: Laptop bag
dimensions: W 40cm X D 4cm x H 30cm
production_leadtime: 30 days (indicative leadtime)
moq: 1’000 unit in black color
price_per_unit: on demand
our_services: technical development - sample - mass production - QC - logistic - shipping
image1:   melazic-bag.jpg
---
Product specifications: tarpaulin fabric, inside upholstery in black Oxford fabric, logo silkscreen and decoration, 1 zipper, neoprene foam inside, 1 compartment, delivered in polybag and

