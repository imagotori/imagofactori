---
layout: product
published: true
title:  HARRY WINSTON
lang: en
product_group: harry_winston
product_type: Display
dimensions: W 35cm X D 20cm x H 44 cm
production_leadtime: 33 days per batch (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   HW-mondrian1.jpg
---
Product specifications: MDF black piano lacquer finishing, images printed and framed on acryl, delivered with a user manual and 10 c-rings, delivered in a carton transportation box

