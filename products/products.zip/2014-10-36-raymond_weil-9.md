---
layout: product
published: true
title:  RAYMOND WEIL
lang: en
product_group: raymond_weil
product_type: Thermo mug
dimensions: W 6cm X D 6cm x H 18.5cm
production_leadtime: 25 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design technical_development sample mass_production QC logistic shipping
image1:   RW-thermo-mug.jpg
---
Product specifications:  thermo mug in FDA certified  PS and PP material,  silver silkscreen of the logo, printed paper glossy silkscreen of the decorative pattern, delivered in transportation carton						
