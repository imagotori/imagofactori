---
layout: product
published: true
title:  CONCORD
lang: en
product_group: concord
product_type: Watch box
dimensions: W 21cm X D 15cm x H 13cm
production_leadtime: 38 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   Concord-standard-box-A.jpg
image2:  Concord-standard-box-B.jpg
---
Product specifications: MDF wrapped by rubber black mat PU, silver silkscreen of the logo, frame in acryl aluminium effect, automatic hinges, removable tray MDF wrapped by rubber bla

