---
layout: product
published: true
title:  HARRY WINSTON
lang: en
product_group: harry_winston
product_type: Watch box
dimensions: W 35cm X D 20cm x H 15cm
production_leadtime: 40 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: technical development - sample - mass production - QC - logistic - shipping
image1:   HW-j-box-B1.jpg
image2:  HW-j-box-B2.jpg
---
Product specifications: MDF, birl bird eyed wood veneer tainted in black, glossy varnish finishing, silver silkscreen on the top, hardware chrome finishing, inside upholstery in kamosho, re

