---
layout: product
published: true
title:  NESCAFÉ
lang: en
product_group: nescafe
product_type: Shopping bag
dimensions: W 28cm X D 16cm x H 38cm
production_leadtime: 28 days (indicative leadtime)
moq: 1’000 unit
price_per_unit: on demand
our_services: design - technical development - sample production - QC - logisitc - shipping
image1:   Nescafe.jpg
---
Product specifications: Oxford red fabric, inside upholstery in red silk fabric, logo silkscreen and decoration, 1 zipper pocket inside, delivered in polybag and trans- portation carton

