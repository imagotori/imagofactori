---
layout: product
published: true
title:  CONCORD
lang: en
product_group: concord
product_type: Lanyard
dimensions: W 16cm X D 2.5cm x H 0.6cm
production_leadtime: 29 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   Concord-lanyard.jpg
---
Product specifications: italian leather rubber treatment, 2 embossed logo, ring in stainless steel chrome finishing, delivered in a black wibalin box with a silver silks- creen of the logo, tran

