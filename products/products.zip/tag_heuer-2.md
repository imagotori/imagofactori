---
layout: product
published: true
title:  TAG HEUER
lang: en
product_group: tag_heuer
product_type: 2 pieces travel watch holder
dimensions: W 16cm X D 9.5cm x H 9.5cm
production_leadtime: 32 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample production - QC - logistic - shipping
image1:   TH-marmotte-vintage.jpg
image2:  TH-marmotte-vintage-B.jpg
---
Product specifications: soft mat brown leather, aluminium anonized with a laser logo engraved, 1 logo embossment inside, 1 cushion in soft mat brown leather with 1 logo embossment, in

