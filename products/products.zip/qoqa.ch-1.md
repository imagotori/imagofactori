---
layout: product
published: true
title:  QOQA.CH
lang: en
product_group: qoqa
product_type: Messenger bag
dimensions: W 40cm X D 18cm x H 35cm
production_leadtime: 30 days (indicative leadtime)
moq: 1’000 unit in black or white color
price_per_unit: on demand
our_services: technical development - sample - mass production - QC - logistic - shipping
image1:   qoqa-messenger-bag-.jpg
---
Product specifications: tarpaulin fabric, inside upholstery in black Oxford fabric, logo silkscreen glossy varnish, 1 pocket inside, 1 compartment, delivered in polybag and transportation

