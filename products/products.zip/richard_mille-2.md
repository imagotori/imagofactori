---
layout: product
published: true
title:  RICHARD MILLE
lang: en
product_group: richard_mille
product_type: Display
dimensions: W 30cm X D 35cm x H 32cm
production_leadtime: 30 days per batch (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   RM-small-display.jpg
---
Product specifications: frame in black and natural aluminium anonized, base in folded acryl black rubber mat lacquer, push-pull wings in natural aluminium anoni- zed and folded acryl b

