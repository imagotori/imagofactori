---
layout: product
published: true
title:  CONCORD
lang: en
product_group: concord
product_type: Watch box
dimensions: W 18cm X D 18cm x H 29cm
production_leadtime: 30 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   Concord-spider-box-.jpg
image2:  Concord-spider-box-b.jpg
---
Product specifications: MDF black mat lacquered, aluminium black anonized insert, glossy varnish silkscreen of the logo, automatic hinges, removable tray MDF wrapped by rubber bla

