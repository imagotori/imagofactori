---
layout: product
published: true
title:  RAYMOND WEIL
lang: en
product_group: raymond_weil
product_type: Head quarter shop in shop
dimensions: multiple
production_leadtime: 30 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: technical development - sample - mass production - QC - logistic - shipping
image1:   RW-Nabucco.jpg
---
Product specifications: MDF ral 8019 mat lacquered, thermo lacquered alumi- nium frame, BNB lockers, exclusive imago factori LED lighting (LED bar,LED shower lighting and ceiling)

