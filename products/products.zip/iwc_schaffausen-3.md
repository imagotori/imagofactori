---
layout: product
published: true
title:  IWC SCHAFFAUSEN
lang: en
product_group: iwc_schaffausen
product_type: USB key
dimensions: W 1.7cm X D 5.5cm x H 1.2cm
production_leadtime: 31 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: technical development - sample - mass production - QC - logistic - shipping
image1:   IWC-usb.jpg
---
Product specifications: real carbone, stainless steel frame chrome finishing, laser engravement, 8GB Samsung chip, delivered with a black mat paper carton box silver silkscreen logo on

