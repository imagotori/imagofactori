---
layout: product
published: true
title:  RAYMOND WEIL
lang: en
product_group: raymond_weil
product_type: Key ring
dimensions: W 5.5cm X D 1.5cm x H 0.7cm
production_leadtime: 32 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: technical development - sample - mass production - QC - logistic - shipping
image1:   RW-key-ring.jpg
---
Product specifications: stainless steel chrome finishing, laser engravement of the pattern and the logo , nylon black cord, stainless steel ring chrome finishing, delivered in a brown carton

