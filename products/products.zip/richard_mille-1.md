---
layout: product
published: true
title:  RICHARD MILLE
lang: en
product_group: richard_mille
product_type: 3 pieces travel watch holder
dimensions: W 23cm X D 12cm x H 8cm
production_leadtime: 27 days
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   RM-marmotte-A.jpg
image2:  RM-marmotte-B.jpg
---
Product specifications: rubber mat black leather, logo embossement, 3 cushions in rubber mat black leather, delivered with a black mat paper carton box silver silkscreen logo on the top

