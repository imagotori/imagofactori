---
layout: product
published: true
title:  EBEL
lang: en
product_group: ebel
product_type: Travel women wallet
dimensions: W 21cm X D 10cm x H 2.5cm
production_leadtime: 30 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: technical development - sample - mass production - QC - logistic - shipping
image1:   ebel-travel-purse.jpg
image2:  ebel-travel-purseb.jpg
---
Product specifications: italian rancho leather, YKK zipper in rose gold outside and inside, inside upholstery in majilite, laser cutting for credit card compartment , logo embossment, deliver

