---
layout: product
published: true
title:  RICHARD MILLE
lang: en
product_group: richard_mille
product_type: Display
dimensions: W 30cm X D 35cm x H 32cm
production_leadtime: 30 days per batch (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design technical_development sample mass_production QC logistic shipping
image1:   RM-small-display.jpg
---
Product specifications:  frame in black and natural aluminium  anonized, base in folded acryl black rubber mat lacquer, push-pull wings in natural aluminium anoni- zed and folded acryl black rubber mat lacquer, removable backdrop in natural aluminium anonized and acryl black rubber mat lacquer with glossy varnish silks- creen, 3D logo letter in anonized aluminium, 3 watch holders in rubber mat black finishing,  delivered with a 3 stair EVA black foam protection,  user manual and transportation carton						
