---
layout: product
published: true
title:  ON DEMAND - CONFIDENTIALITY POLICY
lang: en
product_group: on_demand_-_confidentiality_policy
product_type: Travel speaker
dimensions: W 7.2cm X D 7.2cm x H 7.2cm
production_leadtime: 40 days (indicative leadtime)
moq: 2’000 unit
price_per_unit: on demand
our_services: design technical_development sample mass_production QC logistic shipping
image1:   speaker.jpg
---
Product specifications:  solid wood (wenge veneer) for best sound performance, bluetooth 3.0, 2 watts power output, audible confirmation, built in bass for power- ful bass, NFC connection, mini USB based, hands free calling, 8 hours of playback time, delivered in a branded carton box with a user manual.						
