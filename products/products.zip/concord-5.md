---
layout: product
published: true
title:  CONCORD
lang: en
product_group: concord
product_type: Watch box
dimensions: W 30cm X D 30cm x H 30cm
production_leadtime: 34 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   Concord-quantum-box.jpg
image2:  Concord-quantum-box-2.jpg
---
Product specifications: MDF black glossy lacquered, mat varnish silkscreen of th ewatch mecanism, 2x push button opening system in natural and black aluminium anonized, removable

