---
layout: product
published: true
title:  CONCORD
lang: en
product_group: concord
product_type: Credit card holder
dimensions: W 10cm X D 7cm x H 3cm production_leadtime
production_leadtime: 29 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   Concord-credit-card-holder.jpg
---
Product specifications: italian leather rubber treatment, 1 embossed logo, note clamp in stainless steel smooth brush finishing laser logo engravement, delivered in a black wibalin box w

