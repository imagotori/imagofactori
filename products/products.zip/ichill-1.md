---
layout: product
published: true
title:  ICHILL
lang: en
product_group: ichill
product_type: Giant bag
dimensions: W 140cm X D /cm x H 180cm
production_leadtime: 35 days (indicative leadtime)
moq: 2’000 unit per color
price_per_unit: on demand
our_services: technical development - sample - mass production - QC - logistic - shipping
image1:   Ichill.jpg
---
Product specifications: giant cushion cover in Oxford fabric 1800, roller print technic have been used for the design print, YKK zipper, inside cover for protec- tion, fire retardant (UK - CE

