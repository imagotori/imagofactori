---
layout: product
published: true
title:  AUDEMARS PIGUET
lang: en
product_group: audemars_piguet
product_type: Display
dimensions: W 26cm X D 26cm x H 32cm
production_leadtime: 26 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample - mass production - QC - logistic - shipping
image1:   AP-display.jpg
---
Product specifications: grooved MDF rubber black mat lacquering, blue and red, silkscreen , frame in aluminium anonized, logo brand in 3d stickers chrome finishing , 2 watch holder w

