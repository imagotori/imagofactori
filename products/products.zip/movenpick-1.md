---
layout: product
published: true
title:  MÖVENPICK
lang: en
product_group: movenpick
product_type: Cooler bag
dimensions: W 30cm X D 20cm x H 25cm
production_leadtime: 25 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: design - technical development - sample
image1:   cooler-bag-1.jpg
image2:  cooler-bag-2.jpg
---
Product specifications: printed Oxford, logo silkscreen, YKK zipper, inside melazic bag.jpg

