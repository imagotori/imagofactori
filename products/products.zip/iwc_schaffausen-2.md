---
layout: product
published: true
title:  IWC SCHAFFAUSEN
lang: en
product_group: iwc_schaffausen
product_type: Key ring
dimensions: W 4cm X D 11cm x H 1.4cm
production_leadtime: 24 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: technical development - sample production - QC - logistic - shipping
image1:   IWC-keyring.jpg
---
Product specifications: rubber mat black leather, black cord stitching, stainless steel chrome finishing, laser engravement, delivered with a black mat paper carton box silver silkscreen lo

