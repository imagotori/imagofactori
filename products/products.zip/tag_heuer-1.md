---
layout: product
published: true
title:  TAG HEUER
lang: en
product_group: tag_heuer
product_type: 1 pieces travel watch holder & cufflink case
dimensions: W 16.5cm X D 11.5cm x H 7cm
production_leadtime: 32 days (indicative leadtime)
moq: on demand
price_per_unit: on demand
our_services: technical development - sample production - QC - logistic - shipping
image1:   TH-marmotte-1.jpg
image2:  TH-marmotte-2.jpg
---
Product specifications: soft mat brown leather, logo embossment, 1 cushions kamosho, inside upholstery in kamosho, 1 inside logo embossment, 1 cufflink case soft mat brown leather in

